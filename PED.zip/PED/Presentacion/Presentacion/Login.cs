﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Domain;

namespace Presentacion
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }





        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void RelaeseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Contrasenha.FrmRecovery frmRecovery = new Contrasenha.FrmRecovery();
            frmRecovery.ShowDialog();

        }

        private void txtxUser_Enter(object sender, EventArgs e)
        {
            if(txtxUser.Text== "")
            {
                txtxUser.Text = "";
                txtxUser.BackColor = Color.LightGray;
            }
        }

        private void txtxUser_Leave(object sender, EventArgs e)
        {
            if (txtxUser.Text == "")
            {
                txtxUser.Text = "";
                txtxUser.BackColor = Color.White;
            }
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void txtPass_Enter(object sender, EventArgs e)
        {
            if (txtPass.Text == "")
            {
                txtPass.Text = "";
                txtPass.BackColor = Color.LightGray;
            }
        }

        private void txtPass_Leave(object sender, EventArgs e)
        {
            if (txtPass.Text == "")
            {
                txtPass.Text = "";
                txtPass.BackColor = Color.White;
            }
        }

        private void txtxUser_MouseDown(object sender, MouseEventArgs e)
        {
           // txtxUser.BackColor = Color.Gainsboro;
        }

        private void txtxUser_MouseLeave(object sender, EventArgs e)
        {
           // txtxUser.BackColor = Color.Gainsboro;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            RelaeseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Loguear()
        {

            if (txtxUser.Text != "")
            {
                if (txtPass.Text != "")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(txtxUser.Text, txtPass.Text);
                    if (validLogin == true)
                    {
                        FormInicio frminicio = new FormInicio();
                        DialogResult dr = frminicio.ShowDialog();

                        if (dr == DialogResult.OK)
                        {
                            Limpiar();
                        }


                    }
                    else
                    {
                        MessageBox.Show("Usuario o contraseña incorrectos. \n por favor vuelva a intentarlo");
                        txtPass.Clear();
                        txtxUser.Clear();
                        txtxUser.Focus();
                    }
                }
                else
                {
                    msgError("Por favor ingrese su contraseña correcta");
                }

            }
            else
            {
                msgError("Por favor ingrese su nombre de Usuario correcto");
            }

        }

        private void btnAcceder_Click(object sender, EventArgs e)
        {

            Loguear();

        }

        private void msgError(string Error)
        {
            lblError.Text = Error;
            lblError.Visible = true;
        }

        private void Limpiar()
        {

            //this.Show();

            txtxUser.Clear();
            txtPass.Clear();
            lblError.Visible = false;
            
            txtxUser.Focus();
           
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Estas seguro de que quieres salir de la aplicacion?", "Advertencia",
             MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                Application.Exit();
        }

        private void txtxUser_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                Loguear();
            }

        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                Loguear();
            }

        }
    }
}
