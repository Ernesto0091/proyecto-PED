﻿namespace Inicio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.MenuVertical = new System.Windows.Forms.Panel();
            this.BTNcerrarSesion = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnInventario = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BarraTitulo = new System.Windows.Forms.Panel();
            this.IconoMinimizar = new System.Windows.Forms.PictureBox();
            this.IconMaximizar = new System.Windows.Forms.PictureBox();
            this.IconoCerrar = new System.Windows.Forms.PictureBox();
            this.IconoMInimizarVentana = new System.Windows.Forms.PictureBox();
            this.BtnSLIDE = new System.Windows.Forms.PictureBox();
            this.PanelConetenedor = new System.Windows.Forms.Panel();
            this.MenuVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.BarraTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IconoMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconoCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconoMInimizarVentana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnSLIDE)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuVertical
            // 
            this.MenuVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(174)))), ((int)(((byte)(228)))));
            this.MenuVertical.Controls.Add(this.BTNcerrarSesion);
            this.MenuVertical.Controls.Add(this.button1);
            this.MenuVertical.Controls.Add(this.BtnInventario);
            this.MenuVertical.Controls.Add(this.pictureBox1);
            this.MenuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuVertical.Location = new System.Drawing.Point(0, 0);
            this.MenuVertical.Name = "MenuVertical";
            this.MenuVertical.Size = new System.Drawing.Size(206, 623);
            this.MenuVertical.TabIndex = 0;
            // 
            // BTNcerrarSesion
            // 
            this.BTNcerrarSesion.BackColor = System.Drawing.Color.Black;
            this.BTNcerrarSesion.FlatAppearance.BorderSize = 0;
            this.BTNcerrarSesion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.BTNcerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNcerrarSesion.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNcerrarSesion.ForeColor = System.Drawing.Color.White;
            this.BTNcerrarSesion.Image = ((System.Drawing.Image)(resources.GetObject("BTNcerrarSesion.Image")));
            this.BTNcerrarSesion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTNcerrarSesion.Location = new System.Drawing.Point(0, 574);
            this.BTNcerrarSesion.Name = "BTNcerrarSesion";
            this.BTNcerrarSesion.Size = new System.Drawing.Size(265, 49);
            this.BTNcerrarSesion.TabIndex = 2;
            this.BTNcerrarSesion.Text = "Cerrar Sesion";
            this.BTNcerrarSesion.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 286);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(254, 49);
            this.button1.TabIndex = 1;
            this.button1.Text = "Usuarios";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // BtnInventario
            // 
            this.BtnInventario.BackColor = System.Drawing.Color.DimGray;
            this.BtnInventario.FlatAppearance.BorderSize = 0;
            this.BtnInventario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.BtnInventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnInventario.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInventario.ForeColor = System.Drawing.Color.White;
            this.BtnInventario.Image = ((System.Drawing.Image)(resources.GetObject("BtnInventario.Image")));
            this.BtnInventario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnInventario.Location = new System.Drawing.Point(0, 202);
            this.BtnInventario.Name = "BtnInventario";
            this.BtnInventario.Size = new System.Drawing.Size(254, 49);
            this.BtnInventario.TabIndex = 0;
            this.BtnInventario.Text = "Inventario";
            this.BtnInventario.UseVisualStyleBackColor = false;
            this.BtnInventario.Click += new System.EventHandler(this.BtnInventario_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Inicio.Properties.Resources.icono_01;
            this.pictureBox1.Location = new System.Drawing.Point(-25, -9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 92);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // BarraTitulo
            // 
            this.BarraTitulo.Controls.Add(this.IconoMinimizar);
            this.BarraTitulo.Controls.Add(this.IconMaximizar);
            this.BarraTitulo.Controls.Add(this.IconoCerrar);
            this.BarraTitulo.Controls.Add(this.IconoMInimizarVentana);
            this.BarraTitulo.Controls.Add(this.BtnSLIDE);
            this.BarraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarraTitulo.Location = new System.Drawing.Point(206, 0);
            this.BarraTitulo.Name = "BarraTitulo";
            this.BarraTitulo.Size = new System.Drawing.Size(754, 56);
            this.BarraTitulo.TabIndex = 1;
            this.BarraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BarraTitulo_MouseDown);
            // 
            // IconoMinimizar
            // 
            this.IconoMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IconoMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IconoMinimizar.Image = global::Inicio.Properties.Resources.descarga1;
            this.IconoMinimizar.Location = new System.Drawing.Point(672, 3);
            this.IconoMinimizar.Name = "IconoMinimizar";
            this.IconoMinimizar.Size = new System.Drawing.Size(38, 31);
            this.IconoMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.IconoMinimizar.TabIndex = 4;
            this.IconoMinimizar.TabStop = false;
            this.IconoMinimizar.Visible = false;
            this.IconoMinimizar.Click += new System.EventHandler(this.IconoMinimizar_Click);
            // 
            // IconMaximizar
            // 
            this.IconMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IconMaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IconMaximizar.Image = global::Inicio.Properties.Resources._32763;
            this.IconMaximizar.Location = new System.Drawing.Point(672, 3);
            this.IconMaximizar.Name = "IconMaximizar";
            this.IconMaximizar.Size = new System.Drawing.Size(38, 31);
            this.IconMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.IconMaximizar.TabIndex = 3;
            this.IconMaximizar.TabStop = false;
            this.IconMaximizar.Click += new System.EventHandler(this.IconMaximizar_Click);
            // 
            // IconoCerrar
            // 
            this.IconoCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IconoCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IconoCerrar.Image = global::Inicio.Properties.Resources._61155;
            this.IconoCerrar.Location = new System.Drawing.Point(716, 3);
            this.IconoCerrar.Name = "IconoCerrar";
            this.IconoCerrar.Size = new System.Drawing.Size(38, 31);
            this.IconoCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.IconoCerrar.TabIndex = 1;
            this.IconoCerrar.TabStop = false;
            this.IconoCerrar.Click += new System.EventHandler(this.IconoCerrar_Click);
            // 
            // IconoMInimizarVentana
            // 
            this.IconoMInimizarVentana.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IconoMInimizarVentana.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IconoMInimizarVentana.Image = global::Inicio.Properties.Resources._93631;
            this.IconoMInimizarVentana.Location = new System.Drawing.Point(628, 3);
            this.IconoMInimizarVentana.Name = "IconoMInimizarVentana";
            this.IconoMInimizarVentana.Size = new System.Drawing.Size(38, 31);
            this.IconoMInimizarVentana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.IconoMInimizarVentana.TabIndex = 2;
            this.IconoMInimizarVentana.TabStop = false;
            this.IconoMInimizarVentana.Click += new System.EventHandler(this.IconoMInimizarVentana_Click);
            // 
            // BtnSLIDE
            // 
            this.BtnSLIDE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnSLIDE.Image = global::Inicio.Properties.Resources.Barras_de_menu;
            this.BtnSLIDE.Location = new System.Drawing.Point(0, 3);
            this.BtnSLIDE.Name = "BtnSLIDE";
            this.BtnSLIDE.Size = new System.Drawing.Size(59, 50);
            this.BtnSLIDE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BtnSLIDE.TabIndex = 0;
            this.BtnSLIDE.TabStop = false;
            this.BtnSLIDE.Click += new System.EventHandler(this.BtnSLIDE_Click);
            // 
            // PanelConetenedor
            // 
            this.PanelConetenedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PanelConetenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelConetenedor.Location = new System.Drawing.Point(206, 56);
            this.PanelConetenedor.Name = "PanelConetenedor";
            this.PanelConetenedor.Size = new System.Drawing.Size(754, 567);
            this.PanelConetenedor.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 623);
            this.Controls.Add(this.PanelConetenedor);
            this.Controls.Add(this.BarraTitulo);
            this.Controls.Add(this.MenuVertical);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Opacity = 0.98D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MenuVertical.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.BarraTitulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.IconoMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconoCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IconoMInimizarVentana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnSLIDE)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MenuVertical;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel BarraTitulo;
        private System.Windows.Forms.PictureBox BtnSLIDE;
        private System.Windows.Forms.Panel PanelConetenedor;
        private System.Windows.Forms.PictureBox IconoCerrar;
        private System.Windows.Forms.PictureBox IconoMInimizarVentana;
        private System.Windows.Forms.PictureBox IconoMinimizar;
        private System.Windows.Forms.PictureBox IconMaximizar;
        private System.Windows.Forms.Button BtnInventario;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BTNcerrarSesion;
    }
}

