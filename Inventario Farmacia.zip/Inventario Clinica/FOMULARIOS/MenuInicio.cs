﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using farmacia_ped.formularios;
using Inventario_Clinica.FOMULARIOS;


namespace Inventario_Clinica.FOMULARIOS
{
    public partial class MenuInicio : Form
    {
        public MenuInicio()
        {
            InitializeComponent();
        }


        private void MenuInicio_Load(object sender, EventArgs e)
        {
            panelMenu.Visible = true;
            btnMenu.Visible = false;
            LoadUserData();
        }

      

      
        private void TLPPrincipal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CloseSesion_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void INVENTARIO_Click_1(object sender, EventArgs e)
        {
            Inventario formInventario = new Inventario();
            formInventario.Show();
            this.Hide();
        }

        private void LoadUserData()
        {
            lblName.Text = Autentication.Cache.UserLoginCache.FirstName + "," + Autentication.Cache.UserLoginCache.LastName;
            lblPosicion.Text = Autentication.Cache.UserLoginCache.Position;
            lblEMAIL.Text = Autentication.Cache.UserLoginCache.Email;
        }


        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (panelMenu.Visible == true)
            {
                panelMenu.Visible = false;

            }
            else
            {
                panelMenu.Visible = true;
            }
            btnMenu.Visible = false;
            btnOcultaMenu.Visible = true;
        }

        private void btnUsuarios_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Inventario formInventario = new Inventario();
            formInventario.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (panelMenu.Visible == true)
            {
                panelMenu.Visible = false;

            }
            else
            {
                panelMenu.Visible = true;
            }
            btnOcultaMenu.Visible = false;
            btnMenu.Visible = true;
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Estas seguro de querer cerrar sesión?", "Advertencia",
               MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Estas seguro de querer cerrar sesión?", "Advertencia",
               MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                this.Close();
        }
    }
}
