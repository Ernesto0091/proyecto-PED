﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DataAcces.SqlServer;
using System.Collections;

namespace Domain
{
   public class BD_Productos
    {
        private Productos_Conexion ObjectCD = new Productos_Conexion();


        #region Metodos CRUD


        public DataTable MostrarProd()
        {

            DataTable tabla = new DataTable();
            tabla = ObjectCD.Mostrar();
            return tabla;
        }


        public void InsertarProd(string NombreProducto, string Categoria, string TipoProducto, string Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento)
        {
            ObjectCD.Insertar(NombreProducto,Categoria,TipoProducto,Convert.ToInt32(Cantidad),TipoAlmacenaje,Descripcion,Fechaingreso,FechaVencimiento);
        }

        public void EditarProductos(string NombreProducto, string Categoria, string TipoProducto, string Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento, string Id)
        {
            ObjectCD.EditarProd(NombreProducto, Categoria, TipoProducto, Convert.ToInt32(Cantidad), TipoAlmacenaje, Descripcion, Fechaingreso, FechaVencimiento,Convert.ToInt32(Id));

        }



        public void EliminarProductos(string Id)
        {
            ObjectCD.ELIMINAR(Convert.ToInt32(Id));
        }


        public DataTable Buscar(string ID)
        {
            DataTable tabla = new DataTable();

            tabla = ObjectCD.Buscar(Convert.ToInt32(ID));
            return tabla;
        }

        #endregion



        #region Metodos HASH


        public void InsertHashDomain(string Clave, string Informacion, string TipoProducto, string Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento)
        {
            ObjectCD.InsertarHash(Clave, Informacion, TipoProducto, Convert.ToInt32(Cantidad), TipoAlmacenaje, Descripcion, Fechaingreso, FechaVencimiento);
        }




        #endregion




        Hashtable CrudHash = new Hashtable();



        
        
        


    }
}
