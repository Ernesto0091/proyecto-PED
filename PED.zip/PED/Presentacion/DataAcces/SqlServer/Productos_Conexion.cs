﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAcces.SqlServer
{
    public class Productos_Conexion
    {
        private ConectToSql conexion = new ConectToSql();


        SqlDataReader leer;
        DataTable tabla = new DataTable();
        SqlCommand command = new SqlCommand();

        #region Metodos CRUD
        public DataTable Mostrar()
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "select * from Producto";
            leer = command.ExecuteReader();
            tabla.Load(leer);
            conexion.CerrarConexion();
            return tabla;
        }

        public void Insertar(string NombreProducto, string Categoria, string TipoProducto, int Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento)
        {



            command.Connection = conexion.AbrirConexion();

            command.CommandText = "set language Español";
            command.ExecuteNonQuery();

            command.CommandText = "insert into Producto values('" + NombreProducto + "','" + Categoria + "','" + TipoProducto + "','" + Cantidad + "','" + TipoAlmacenaje + "','" + Descripcion + "','"+Fechaingreso+"','"+FechaVencimiento+"')";

            command.CommandType = CommandType.Text;

            command.ExecuteNonQuery();

            command.Parameters.Clear();




        }




        public void EditarProd(string NombreProducto, string Categoria, string TipoProducto, int Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento, int Id)
        {


            command.Connection = conexion.AbrirConexion();
            command.CommandText = "EditarProductos";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@nombre", NombreProducto);
            command.Parameters.AddWithValue("@Categoria", Categoria);
            command.Parameters.AddWithValue("@Tipo", TipoProducto);
            command.Parameters.AddWithValue("@Cantidad", Cantidad);
            command.Parameters.AddWithValue("@TipoAlmacenaje", TipoAlmacenaje);
            command.Parameters.AddWithValue("@Desc", Descripcion);
            command.Parameters.AddWithValue("@FechaIngreso", Fechaingreso);
            command.Parameters.AddWithValue("@FechaVencimiento", FechaVencimiento);
            command.Parameters.AddWithValue("@Id", Id);
            command.ExecuteNonQuery();
            command.Parameters.Clear();


        }



        public void ELIMINAR(int Id)
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "EliminarProductos";
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@IdProd", Id);
            command.ExecuteNonQuery();
            command.Parameters.Clear();
        }


        public DataTable Buscar(int IDPROD)
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "BuscarCod";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Id", IDPROD);

            leer = command.ExecuteReader();
            tabla.Load(leer);
            conexion.CerrarConexion();

            command.Parameters.Clear();

            return tabla;

            //  command.Parameters.Clear();


        }

        #endregion

        #region Metodos HASH
        public void InsertarHash(string Clave,string Informacion, string TipoProducto, int Cantidad, string TipoAlmacenaje, string Descripcion, DateTime Fechaingreso, DateTime FechaVencimiento)
        {
            command.Connection = conexion.AbrirConexion();

            command.CommandText = "set language Español";
            command.ExecuteNonQuery();

            command.CommandText = "insert into Producto values('" + Clave + "','" + Informacion + "','" + TipoProducto + "','" + Cantidad + "','" + TipoAlmacenaje + "','" + Descripcion + "','"+Fechaingreso+"','"+FechaVencimiento+"')";

            command.CommandType = CommandType.Text;

            command.ExecuteNonQuery();

            command.Parameters.Clear();

        }




        #endregion



    }
}
