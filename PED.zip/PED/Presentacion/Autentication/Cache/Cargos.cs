﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autentication.Cache
{
   public class Cargos
    {

        public const string Administrador = "Administrador";
        public const string Empleado = "Empleado";
        public const string Adminisrador = "Adminisrador";
    }
}
