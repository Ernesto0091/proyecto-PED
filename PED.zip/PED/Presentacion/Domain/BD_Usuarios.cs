﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAcces.SqlServer;
using System.Data;

namespace Domain
{
    public class BD_Usuarios
    {

        Usuarios_Conexion ObjectUsarios = new Usuarios_Conexion();





        public DataTable MostrarUsuarios()
        {
            DataTable tabla = new DataTable();
            tabla = ObjectUsarios.Mostrar();
            return tabla;
        }


        public void InsrtUsuHash(string LoginName, string Pass, string Fname, string Lname, string position, string Email)
        {
            ObjectUsarios.InsertarUsuHash(LoginName, Pass, Fname, Lname, position, Email);

        }


        public void EditUsuarios(string LoginName, string Pass, string Fname, string Lname, string Position, string Email, string Id)
        {
            ObjectUsarios.EditUsuHash(LoginName,Pass,Fname,Lname,Position,Email,Convert.ToInt32(Id));

        }


        public void DeleteUsers(string IdUser)
        {
            ObjectUsarios.DeleteUser(Convert.ToInt32(IdUser));
        }


    }
}
