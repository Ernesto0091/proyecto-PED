﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Dynamic;
using System.Runtime.InteropServices;
using Domainn;



namespace Inventario_Clinica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void RelaeseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

     

      
      
     

      


       

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

  
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            RelaeseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            RelaeseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnAcceso_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text != String.Empty)
            {
                if (txtContraseña.Text != "")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(txtUsuario.Text, txtContraseña.Text);
                    if(validLogin == true)
                    {
                        MessageBox.Show("ALOOJAAA!!!");
                    }
                    else
                    {
                        Merror("Nel papu, esta malo xddd");
                        txtContraseña.Clear();

                    }
                }
                else Merror("Por favor ingrese su contraseña");

            }
            else Merror("Por favor ingrese su Nombre de usuario");

        }

        private void Merror(string msg)
        {
            lblErrorMessage.Text =  msg;
            lblErrorMessage.Visible = true;
        }

    }

    }

