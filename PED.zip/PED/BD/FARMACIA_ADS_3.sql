use master 



create database FARMACIA_ADS_3

use FARMACIA_ADS_3

-- Creacion  de tablas




create table users(
UserID int identity (1,1) primary key,
LoginName nvarchar (100) unique not null,
password nvarchar (100) not null,
FirstName nvarchar (100) not null,
LastName nvarchar (100) not null,
Position nvarchar (100) not null,
Email nvarchar (100) not null
)







  

create table Categoria
(
CodCategoria varchar(50) primary key ,
NombreCategoria varchar(100)not null
)



create table TipoProducto
(
TipoID varchar (50) primary key,
TipoP varchar (50) 
)



create table Producto
(
CodProducto int identity(1,1) primary key,
NombreProducto varchar (100) not null,
CategoriaProducto varchar (50) not null,
Tipoproduct varchar(50) not null,
Cantidad int not null,
TipoAlmacenaje varchar(50)not null,
DescripcionProducto varchar(500) not null,
FechaIngreso DateTime not null,
FechaVencimiento DateTime not null
)






alter table Producto
add Constraint CodCat_FK
foreign key (CategoriaProducto)
references Categoria (CodCategoria)


alter table Producto
add constraint TipoP_FK
foreign key (Tipoproduct)
references TipoProducto(TipoID)



--Restricciones


alter table producto
add constraint FV_P
Check (FechaVencimiento > FechaIngreso)

alter table producto
ADD constraint Cant_P
check (Cantidad>0)


-- insertando los datos////
insert into users values ('Katherine','123','Katherine','Apellido','adminisrador','Katherine@gmail.com')

insert into users values ('Cesar','Cesar1','Cesar','Ramirez','adminisrador','Cesar@gmail.com')

insert into users values ('Juan','donjuan','Juan','JuanJuan','Empleado','Juan@gmail.com')

insert into users values ('Ernesto','admin','Ernesto','Mu�oz','administrador','samus.0091@gmail.com')
insert into users values ('Mario','Bros','Mario','Menjivar','administrador','mariomenjivar11@gmail.com')

select * from users

--/////
--/////
insert into Categoria values('001','Ginegologia')

insert into Categoria values('002','Odontologia')
insert into Categoria values('003','Medicina General')

select * from Categoria

--////
--////
insert into TipoProducto values('0001','Analgesico')
insert into TipoProducto values('0002','Antiacidos')
insert into TipoProducto values('0003','Antiulcerosos')
insert into TipoProducto values('0004','Anti�cidos')
insert into TipoProducto values('0005','Antial�rgicos')
insert into TipoProducto values('0006','Antidiarreicos')
insert into TipoProducto values('0007','Laxantes')
insert into TipoProducto values('0008','Antiinflamatorios')
insert into TipoProducto values('0009','Antipir�ticos')
insert into TipoProducto values('0010','Antitusivos')
insert into TipoProducto values('0011','Lucol�ticos')

select* from TipoProducto

--////
--////
insert into Producto values ('Yo','003','0001','1','Cuerpo humano','Fabuloso',getdate(),'2020-4-1')
insert into Producto values ( 'Yo','003','0010','500','Cuerpo humano','Fabuloso',getdate(),'2020-4-1')


insert into Producto values('PruebaFechaGetTime2', '001','0001','123','qwert','qwerty',getdate(),'4-4-2020 00:00:00')

insert into Producto values('PruebaFechagettime', '001','0001','12','rtrthrwtwh','werghwwt',getdate(),'2020-4-3')

insert into Producto values('pruebaFIcopiada1', '002','0006','12','dsadbda','afdbhdfasdfdaf','2020-03-31','4/4/2020 00:00:00')

insert into Producto values('PruebaFecha', '003', '0004', '23', 'erjhbwn', 'shrthrwashwfhrth', '2020-03-31' ,'4-4-2020' )
select * from Producto


insert into Producto values('PruebaFecha', '003', '0004', '23', 'erjhbwn', 'shrthrwashwfhrth', '31/3/2020 00:00:00', '4/4/2020 00:00:00')


--este no se puedde ingresar
insert into Producto values('drgwfgejewhrwe', '002', '0003', '23', 'hfsjgnsfgnj', 'syrjtu', getdate(), '13/4/2020 00:00:00')


insert into Producto values('drgwfgejewhrwe', '002', '0001', '23', 'hfsjgnsfgnj', 'syrjtu', getdate(), '4/24/2020 00:00:00')

--CADENAPRUEBA VS
insert into Producto values('PRUEBAS DE PRUEBAS', '002', '0007', '1234', 'PRUEBA', 'PRUEBA', '31/3/2020 00:00:00', '24/4/2020 00:00:00')


insert into Producto values('jbjsd', '001', '0001', '45', 'dhfgfsn', 'ftyfgyhmujf', '1/4/2020 00:00:00', '25/6/2020 00:00:00')

insert into Producto values('qwetrthgdys', '002', '0002', '56', 'xhgjv', 'hjdfhs', '31/3/2020 00:00:00', '6/5/2020 00:00:00')

insert into Producto values('hfghbshdf', '002', '0002', '234', 'warefhshdfhhfd', 'shwrthwrth', '1/4/2020 17:40:20', '18/6/2020 09:44:10')

insert into Producto values('Prueba try', '003', '0003', '35', 'sdtx', 'ftdbds', '1/4/2020 17:40:20', '24/4/2020 10:36:29')
select @@LANGUAGE
set language Espa�ol
set dateformat dmy


create proc MostrarProductos
as
select * from Producto
exec MostrarProductos

--//
create proc EditarProductos

@nombre varchar (100),
@Categoria varchar (50),
@Tipo varchar(50),
@Cantidad int,
@TipoAlmacenaje varchar(50),
@Desc varchar(500),
@FechaIngreso DateTime,
@FechaVencimiento DateTime,
@Id int
as
update Producto set NombreProducto=@nombre,Categoria=@Categoria,Tipoproduct=@Tipo,Cantidad=@Cantidad,TipoAlmacenaje=@TipoAlmacenaje,DescripcionProducto=@Desc,FechaIngreso=@FechaIngreso,FechaVencimiento=@FechaVencimiento
where CodProducto= @Id

EXec EditarProductos 'yo EDITADO','003','0003','35','sdtx','ftdbds','2020-01-04 17:40:20.000','2020-01-10 17:40:20.000',1
	


create proc EliminarProductos
@IdProd int
as
delete from Producto where CodProducto=@IdProd

exec EliminarProductos 10


create proc BuscarCod
@Id int 
as
select * from Producto where CodProducto = @Id 

 exec BuscarCod 






select * from users where LoginName='Ernesto' and password= 'admin'


declare @user nvarchar(100)='Ernesto'
declare @pass nvarchar(100)='admin'
select * from users where LoginName= @user and password=@pass



declare @user nvarchar(100) = 'Ernesto'
declare @mail nvarchar(100) = 'samus.0091@gmail.com'
select * from users where LoginName=@user or Email = @mail




create Proc EditarUsuarios01
@LoginName nvarchar (100),
@pass nvarchar (100),
@Fname nvarchar(100),
@Lname nvarchar(100),
@Posicion nvarchar(100),
@email varchar(100),
@Id int
as
update users set LoginName=@LoginName,password=@pass,FirstName=@Fname,LastName=@Lname,Position=@Posicion,Email=@email
where UserID=@Id

exec EditarUsuarios01 'Daniel','D1','Daniel','Nose','administrador','Daniel@gmail.com',1005

select * from users




create proc EliminarUsers
@Iduser int
as
delete  from users where UserID = @Iduser


exec EliminarUsers 1003