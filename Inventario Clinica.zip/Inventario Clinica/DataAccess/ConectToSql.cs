﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DataAccess
{
    public abstract class ConectToSql
    {
        private readonly string conectionstring;
        public ConectToSql()
        {
            conectionstring = "server=DESKTOP-R9K04L5\\PC1;DataBase= FARMACIA; integrated security= true";
        }
        protected SqlConnection GetConection()
        {
            return new SqlConnection(conectionstring);
        }

    }
}
