﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace DataAccess
{
   public class UserDat:ConectToSql
    {
        public bool Login(string user, string Pass)
        {
            using (var conection = GetConection())
            {
                conection.Open();

                using (var comand = new SqlCommand())
                {
                    comand.Connection = conection;
                    comand.CommandText = "select * from users where LoginName= @user and password=@pass";

                    comand.Parameters.AddWithValue("@user", user);
                    comand.Parameters.AddWithValue("@pass", Pass);
                    comand.CommandType = CommandType.Text;
                    SqlDataReader reader = comand.ExecuteReader();
                    if (reader.HasRows)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }

            }
        }
    }
}
