﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domain;
namespace Contrasenha
{
    public partial class FrmRecovery : Form
    {
        public FrmRecovery()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var user = new UserModel();
            var result = user.RecoveryPassword(txtCorreo.Text);
            lblRespuesta.Text = result;
            lblRespuesta.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblRespuesta.Visible = false;
        }

        private void lblRespuesta_Click(object sender, EventArgs e)
        {

        }
    }
}
