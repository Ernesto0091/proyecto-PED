﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataAcces.SqlServer
{
    public  class Usuarios_Conexion
    {
        ConectToSql conexion = new ConectToSql();

        SqlDataReader leer;

        DataTable tabla = new DataTable();

        SqlCommand command = new SqlCommand();



        public DataTable Mostrar()
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "select * from users";
            leer = command.ExecuteReader();
            tabla.Load(leer);
            conexion.CerrarConexion();
            return tabla;
        }




        public void InsertarUsuHash(string LoginName, string Pass, string FName, string LName, string position, string Email)
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "insert into users values('"+LoginName+"','"+Pass+"','"+FName+"','"+LName+"','"+position+"','"+Email+"')";
            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();
            command.Parameters.Clear();

        }


        public void EditUsuHash(string LoginName, string Pass, string FName, string LName, string position, string Email, int Id)
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "EditarUsuarios01";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@LoginName", LoginName);
            command.Parameters.AddWithValue("@pass", Pass);
            command.Parameters.AddWithValue("@Fname", FName);
            command.Parameters.AddWithValue("@Lname", LName);
            command.Parameters.AddWithValue("@Posicion", position);
            command.Parameters.AddWithValue("@email", Email);
            command.Parameters.AddWithValue("@Id", Id);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

        }

        public void DeleteUser(int IdUser)
        {
            command.Connection = conexion.AbrirConexion();
            command.CommandText = "EliminarUsers";
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Iduser",IdUser);
            command.ExecuteNonQuery();
            command.Parameters.Clear();
        }





    }
}
