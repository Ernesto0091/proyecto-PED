﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Autentication;

namespace DataAccess
{
   public class UserDat:ConectToSql
    {
        public bool Login(string user, string Pass)
        {
            using (var conection = GetConection())
            {
                conection.Open();

                using (var comand = new SqlCommand())
                {
                    comand.Connection = conection;
                    comand.CommandText = "select * from users where LoginName= @user and password=@pass";

                    comand.Parameters.AddWithValue("@user", user);
                    comand.Parameters.AddWithValue("@pass", Pass);
                    comand.CommandType = CommandType.Text;
                    SqlDataReader reader = comand.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Autentication.Cache.UserLoginCache.IdUser = reader.GetInt32(0);
                            Autentication.Cache.UserLoginCache.FirstName = reader.GetString(3);
                            Autentication.Cache.UserLoginCache.LastName = reader.GetString(4);
                            Autentication.Cache.UserLoginCache.Position = reader.GetString(5);
                            Autentication.Cache.UserLoginCache.Email = reader.GetString(6);
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }

            }
        }
    }
}
