﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domain;
using System.Collections;

namespace Presentacion
{
    public partial class FormUsuarios : Form
    {

        BD_Usuarios metUsuarios = new BD_Usuarios();
        private string IdUser = null;
        private bool Editar = false;


        private void MostrarUsuarios()
        {
            BD_Usuarios Usuarios = new BD_Usuarios();
            dtgvUsuarios.DataSource = Usuarios.MostrarUsuarios();
        }


       
        public FormUsuarios()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MostrarUsuarios();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            this.DialogResult = DialogResult.OK;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            if (Editar == false)
            {
                try
                {
                    Hashtable UsuariosHash = new Hashtable();

                    object Llave = txtLoginName.Text;
                    object Valor = txtPass.Text;

                    UsuariosHash.Add(Llave, Valor);

                    object ValorObtenido = UsuariosHash[Llave];

                    metUsuarios.InsrtUsuHash(Llave.ToString(), ValorObtenido.ToString(), txtNombre.Text, txtApellido.Text, txtPosicion.Text, txtCorreo.Text);
                    MessageBox.Show("El Usuario ha sido agregado exitosamente");
                    Limpiar();
                    MostrarUsuarios();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo insertar los datos " + ex);
                }

            }
            if (Editar == true)
            {
                try
                {
                    Hashtable UsuariosHash = new Hashtable();

                    object Llave = txtLoginName.Text;
                    object Valor = txtPass.Text;

                    UsuariosHash.Add(Llave, Valor);

                    object ValorObtenido = UsuariosHash[Llave];

                    metUsuarios.EditUsuarios(Llave.ToString(), ValorObtenido.ToString(), txtNombre.Text, txtApellido.Text, txtPosicion.Text, txtCorreo.Text,IdUser);
                    MessageBox.Show("El Usuario ha sido Editado exitosamente");
                    Editar = false;
                    Limpiar();
                    MostrarUsuarios();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo Editar los datos " + ex);

                }
            }


        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dtgvUsuarios.SelectedRows.Count > 0)
            {
                Editar = true;

                txtLoginName.Text = dtgvUsuarios.CurrentRow.Cells["LoginName"].Value.ToString();
                txtPass.Text = dtgvUsuarios.CurrentRow.Cells["password"].Value.ToString();
                txtNombre.Text = dtgvUsuarios.CurrentRow.Cells["FirstName"].Value.ToString();
                txtApellido.Text = dtgvUsuarios.CurrentRow.Cells["LastName"].Value.ToString();
                txtPosicion.Text = dtgvUsuarios.CurrentRow.Cells["Position"].Value.ToString();
                txtCorreo.Text = dtgvUsuarios.CurrentRow.Cells["Email"].Value.ToString();
                IdUser = dtgvUsuarios.CurrentRow.Cells["UserID"].Value.ToString();

            }
            else
            {
                MessageBox.Show("Por favor selecione una fila");
            }

        }


        public void Limpiar()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtLoginName.Text = "";
            txtPass.Text = "";
            txtPosicion.Text = "";
            txtCorreo.Text = "";
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            if(dtgvUsuarios.SelectedRows.Count>0)
            {
                IdUser = dtgvUsuarios.CurrentRow.Cells["UserID"].Value.ToString();
                metUsuarios.DeleteUsers(IdUser);
                MessageBox.Show("El usuario ha sido eliminado exitosamente");
                MostrarUsuarios();

            }
            else
            {
                MessageBox.Show("por favr selecciones una fila");
            }



        }
    }

   
}
