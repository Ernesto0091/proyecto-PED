﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcces.MailServices
{
    class SystemSuport:MailMasterServices
    {

        public SystemSuport()
        {
            senderEmail = "soporteemail.0091@gmail.com";
            password = "SoporteFarmacia.01";
            host = "smtp.gmail.com";
            port = 587;
            ssl = true;
            initializeSmtpClient();
        }
    }
}
