﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAcces
{
    public  class ConectToSql
    {
        private readonly string ConectionString;
        public ConectToSql()
        {
            ConectionString = "Server=.\\PC1;Database=FARMACIA_ADS_3; integrated security= true";
        }
        protected SqlConnection getConection()
        {
            return new SqlConnection(ConectionString);
        }


        //Conexion para el crud
        private SqlConnection Conexion = new SqlConnection("Server=.\\PC1;Database=FARMACIA_ADS_3; integrated security= true");

        public SqlConnection AbrirConexion()
        {
            if (Conexion.State == ConnectionState.Closed)
                Conexion.Open();

            return Conexion;
        }

        public SqlConnection CerrarConexion()
        {
            if (Conexion.State == ConnectionState.Open)
                Conexion.Close();
            return Conexion;
        }
    }
}
