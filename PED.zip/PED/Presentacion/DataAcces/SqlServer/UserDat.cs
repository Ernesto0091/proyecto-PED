﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Autentication.Cache;

namespace DataAcces
{
  public  class UserDat:ConectToSql
    {
        public bool Login (string user, string pass)
        {
            using (var conection = getConection())
            {
                conection.Open();

                using (var command = new SqlCommand())
                {
                    command.Connection = conection;
                    command.CommandText = "select * from users where LoginName= @user and password=@pass";
                    command.Parameters.AddWithValue("@user",user);
                    command.Parameters.AddWithValue("@pass", pass);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    if(reader.HasRows)
                    {
                        while(reader.Read())
                        {
                            UserLoginCache.IdUser = reader.GetInt32(0);
                            UserLoginCache.FirstName = reader.GetString(3);
                            UserLoginCache.LastName = reader.GetString(4);
                            UserLoginCache.Position = reader.GetString(5);
                            UserLoginCache.Email = reader.GetString(6);
                        }
                        return true;
                    }
                    else
                        return false;
                }
               
            }
        }

        public void Permiso()
        {
            if (Autentication.Cache.UserLoginCache.Position == Autentication.Cache.Cargos.Adminisrador || UserLoginCache.Position == Autentication.Cache.Cargos.Administrador)
            {

            }
            if (UserLoginCache.Position == Cargos.Empleado)
            {

            }
        }

        public string RecuperarContraseña (string userRespuesta )
        {
            using (var connection = getConection())
            {
                connection.Open();
                using (var command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "select * from users where LoginName=@user or Email = @mail";
                    command.Parameters.AddWithValue("@user", userRespuesta);
                    command.Parameters.AddWithValue("@mail", userRespuesta);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read() == true)
                    {
                        string userName = reader.GetString(3) + ", " + reader.GetString(4);
                        string userMail = reader.GetString(6);
                        string acountPassword = reader.GetString(2);

                        var mailService = new MailServices.SystemSuport();
                        mailService.sedEmail(
                            subject:"SYSTEM: solicitud de recuperacion de contraseña",
                            body:"Hola, "+userName+"\n tu solicitud para recuperar tu contraseña.\n"+
                            "tu contraseña es: "+ acountPassword,
                            recipientEmail: new List<string> { userMail}
                            );

                        return "Tu solucitud ha sido enviada,"+
                            "Revisa tu Correo electronico";


                    }
                    else
                    {
                        return "Lo sentimos, tu no tienes una cuenta vinculada a este correo electronico o nombre de usuario";
                    }



                }

            }
        }

       


    }
}
