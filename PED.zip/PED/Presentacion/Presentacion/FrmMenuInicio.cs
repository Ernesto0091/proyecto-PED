﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Autentication.Cache;

namespace Presentacion
{
    public partial class FormInicio : Form
    {
        public FormInicio()
        {
            InitializeComponent();
        }

        //Codigo para Poder mover la ventana del formulario arrastrandolo

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wpram, int lpram);

        //SLIDE! Codigo para Efecto de botones "menu despegable"
        private void BtnSLIDE_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 250)
            {
                MenuVertical.Width = 70;
            }
            else
            {
                MenuVertical.Width = 250;
            }
        }
        //Metodo para cerra el programa

        private void IconoCerrar_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("¿Está seguro que desea cerrar?", "Alerta¡¡", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }


        //Botones maximizar,minimizar
        private void IconMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            IconoMinimizar.Visible = true;
            IconMaximizar.Visible = false;


        }

        private void IconoMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            IconoMinimizar.Visible = false;
            IconMaximizar.Visible = true;
        }

        private void IconoMInimizarVentana_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        //Metodo para abrir los formularios dentro del panel del menu

        private void AbrirFormInpanel(object Formhijo)
        {
            if (this.PanelConetenedor.Controls.Count > 0)
                this.PanelConetenedor.Controls.RemoveAt(0);

            Form fh = Formhijo as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.PanelConetenedor.Controls.Add(fh);
            this.PanelConetenedor.Tag = fh;
            fh.Show();
        }


        //BOTONES INVENTARIO Y USUARIOS

        private void BtnInventario_Click(object sender, EventArgs e)
        {
            Inventario frmInventario = new Inventario();
            DialogResult dr =  frmInventario.ShowDialog();
           
            
        }

        
        private void Button1_Click_1(object sender, EventArgs e)
        {
           FormUsuarios formUsuarios = new FormUsuarios();
            DialogResult dr = formUsuarios.ShowDialog();
        }

       
        //MOSTRAR LOGO AL INCIO Y AL CERRAR FORMS
        private void MostrarLogo()
        {
            AbrirFormInpanel(new FormLogo());
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            MostrarLogo();
            LoadUserData();
            //Permisos
            if(UserLoginCache.Position==Cargos.Empleado)
            {
                btnUsuarios.Enabled = false;
            }
        }

        private void MostrarlogoAlcerrarForm (object sender,FormClosedEventArgs e)
        {
            MostrarLogo();
        }

        private void MenuVertical_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BTNcerrarSesion_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Estas seguro de que quieres cerrar sesion?", "Advertencia",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                this.DialogResult =DialogResult.OK;
                this.Close();
            //FormLogin formLogin = new FormLogin();
            //formLogin.Show();

        }

        private void LoadUserData()
        {
            lblCorreo.Text = UserLoginCache.Email;
            lblNombre.Text = UserLoginCache.FirstName+" "+ UserLoginCache.LastName;
            lblPosicion.Text = UserLoginCache.Position;
        }

        private void PanelConetenedor_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
