﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Clinica
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            INICIO INICIO = new INICIO();
            if(INICIO.ShowDialog()==DialogResult.OK)
            {
                Application.Run(new Form1());
            }
        }
    }
}
