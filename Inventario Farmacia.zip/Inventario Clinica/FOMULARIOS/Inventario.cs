﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace farmacia_ped.formularios
{
    public partial class Inventario : Form
    {
        public Inventario()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Inventario_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Inventario_Clinica.FOMULARIOS.MenuInicio formMenuInicio = new Inventario_Clinica.FOMULARIOS.MenuInicio();
            formMenuInicio.Show();
            
            this.Hide();
            this.Close();
        }
    }
}
