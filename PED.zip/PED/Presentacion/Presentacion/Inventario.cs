﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domain;
using System.Collections;

namespace Presentacion
{
    public partial class Inventario : Form
    {
        BD_Productos metProd = new BD_Productos();
        private string IdProducto = null;
        private bool Editar = false;
        //  Hashtable CrudHash = new Hashtable();


        #region CRUD
        private void MostrarProd()
        {
            BD_Productos metProdmOSTRAR = new BD_Productos();
            dgvProductos.DataSource = metProdmOSTRAR.MostrarProd();
        }



        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                try
                {
                    metProd.InsertarProd(txtNombreMedicamento.Text, cmbCategoria.SelectedItem.ToString(), cmbTipoproductos.SelectedItem.ToString(), txtCantidad.Text, txtTipoAlmacenaje.Text, txtDescripcion.Text, dtpfechaIngreso.Value, dtpFechaVencimiento.Value);
                    MessageBox.Show("El producto se inserto correctamente");
                    MostrarProd();
                    Clear();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo insertar los datos " + ex);
                }

            }
            if (Editar == true)
            {
                try
                {
                    metProd.EditarProductos(txtNombreMedicamento.Text, cmbCategoria.SelectedItem.ToString(), cmbTipoproductos.SelectedItem.ToString(), txtCantidad.Text, txtTipoAlmacenaje.Text, txtDescripcion.Text, dtpfechaIngreso.Value, dtpFechaVencimiento.Value, IdProducto);
                    MessageBox.Show("El producto se edito correctamente");
                    MostrarProd();
                    Editar = false;
                    Clear();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo Editar los datos " + ex);

                }
            }


        }




        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                Editar = true;

                txtNombreMedicamento.Text = dgvProductos.CurrentRow.Cells["NombreProducto"].Value.ToString();
                cmbCategoria.Text = dgvProductos.CurrentRow.Cells["CategoriaProducto"].Value.ToString();
                cmbTipoproductos.Text = dgvProductos.CurrentRow.Cells["TipoProduct"].Value.ToString();
                txtCantidad.Text = dgvProductos.CurrentRow.Cells["Cantidad"].Value.ToString();
                txtTipoAlmacenaje.Text = dgvProductos.CurrentRow.Cells["TipoAlmacenaje"].Value.ToString();
                txtDescripcion.Text = dgvProductos.CurrentRow.Cells["DescripcionProducto"].Value.ToString();
                dtpfechaIngreso.Text = dgvProductos.CurrentRow.Cells["FechaIngreso"].Value.ToString();
                dtpFechaVencimiento.Text = dgvProductos.CurrentRow.Cells["FechaVencimiento"].Value.ToString();
                IdProducto = dgvProductos.CurrentRow.Cells["CodProducto"].Value.ToString();

            }
            else
            {
                MessageBox.Show("Por favor selecione una fila");
            }
        }




        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                IdProducto = dgvProductos.CurrentRow.Cells["CodProducto"].Value.ToString();
                metProd.EliminarProductos(IdProducto);
                MessageBox.Show("El elemento seleccionado ha sido eliminado");
                MostrarProd();

            }
            else
            {
                MessageBox.Show("Por favor selecione una fila");
            }
        }






        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtBuscarProductos.Text == "")
                {
                    MessageBox.Show("No puede buscar elementos vacios");
                }
                else
                {
                    IdProducto = txtBuscarProductos.Text; ;

                    dgvProductos.DataSource = metProd.Buscar(IdProducto);


                    Clear();

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("A ocurrido un error" + ex);
            }



        }

        #endregion










        #region CRUD HASH




        private void btnAgregarHAs_Click(object sender, EventArgs e)
        {
            try
            {
                // string Clave=txtNombreMedicamento.Text, Info=cmbCategoria.Text;
                object llave = txtNombreMedicamento.Text;
                object valor = cmbCategoria.SelectedItem.ToString();

                Hashtable HashCrud = new Hashtable();
                HashCrud.Add(llave, valor);


                object valorObtenido = HashCrud[llave];

                metProd.InsertHashDomain(llave.ToString(), valorObtenido.ToString(), cmbTipoproductos.Text, txtCantidad.Text, txtTipoAlmacenaje.Text, txtDescripcion.Text, dtpfechaIngreso.Value, dtpFechaVencimiento.Value);
                MessageBox.Show("El producto se ingreso exitosamente");
                MostrarProd();
                Clear();
            }catch(Exception ex)
            {
                MessageBox.Show(""+ ex);
            }

        }









        #endregion








        public Inventario()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PanelFunciones_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Inventario_Load(object sender, EventArgs e)
        {
            Categorias();
            Tiporoductos();
            MostrarProd();


        }





        private void Categorias()
        {
            cmbCategoria.Items.Add("001");
            cmbCategoria.Items.Add("002");
            cmbCategoria.Items.Add("003");
        }

        private void Tiporoductos()
        {
            cmbTipoproductos.Items.Add("0001");
            cmbTipoproductos.Items.Add("0002");
            cmbTipoproductos.Items.Add("0003");
            cmbTipoproductos.Items.Add("0004");
            cmbTipoproductos.Items.Add("0005");
            cmbTipoproductos.Items.Add("0006");
            cmbTipoproductos.Items.Add("0007");
            cmbTipoproductos.Items.Add("0008");
            cmbTipoproductos.Items.Add("0009");
            cmbTipoproductos.Items.Add("0010");
            cmbTipoproductos.Items.Add("0011");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void dtpfechaIngreso_ValueChanged(object sender, EventArgs e)
        {
            //DateTime Fecha = 2020 - 03 - 30 16:23:03.483;
        }

        private void dgvProductos_MouseDown(object sender, MouseEventArgs e)
        {

        }




        private void nudCantidad_ValueChanged(object sender, EventArgs e)
        {

        }





        private void Clear()
        {
            txtNombreMedicamento.Text = "";
            txtTipoAlmacenaje.Text = "";
            txtDescripcion.Text = "";
            txtCantidad.Text = "";
            cmbCategoria.Text = "";
            cmbTipoproductos.Text = "";
            dtpfechaIngreso.Value = DateTime.Today;
            dtpFechaVencimiento.Value = DateTime.Today;
            txtBuscarProductos.Text = "";
        }


        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void btnMostrar_Click(object sender, EventArgs e)
        {
            BD_Productos metProdmOSTRAR = new BD_Productos();
            dgvProductos.DataSource = metProdmOSTRAR.MostrarProd();
        }


    }
}
