﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAcces;

namespace Domain
{
    public class UserModel
    {
        UserDat userdat = new UserDat();

        public bool LoginUser(string user, string pass)
        {
            return userdat.Login(user, pass);
        }

        public string RecoveryPassword(string userRequesting)
        {
            return userdat.RecuperarContraseña(userRequesting);

        }

        public void Permiso()
        {
            if (Autentication.Cache.UserLoginCache.Position == Autentication.Cache.Cargos.Adminisrador || Autentication.Cache.UserLoginCache.Position == Autentication.Cache.Cargos.Administrador)
            {

            }
            if (Autentication.Cache.UserLoginCache.Position == Autentication.Cache.Cargos.Empleado)
            {

            }
        }

    }
}
