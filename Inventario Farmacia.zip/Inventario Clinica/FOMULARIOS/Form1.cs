﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Dynamic;
using System.Runtime.InteropServices;
using Domainn;
using farmacia_ped.formularios;
using Inventario_Clinica.FOMULARIOS;


namespace Inventario_Clinica
{



    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void RelaeseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("estas seguro de que quieres salir de la Aplicacion?", "advertencia",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)

                Application.Exit();
        }






        //INICIO inicio = new INICIO();
        //Form1 fm1 = new Form1();
        Inventario inventario = new Inventario();
        MenuInicio menu = new MenuInicio();







        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            RelaeseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            RelaeseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnAcceso_Click(object sender, EventArgs e)
        {


            if (txtUsuario.Text != String.Empty)
            {
                if (txtContraseña.Text != "")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(txtUsuario.Text, txtContraseña.Text);
                    if (validLogin == true)
                    {
                        menu.Show();
                        menu.FormClosed += LogOut;
                        this.Hide();


                    }
                    else
                    {
                        Merror("Nel papu, esta malo xddd");
                        txtContraseña.Clear();

                    }
                }
                else Merror("Por favor ingrese su contraseña");

            }
            else Merror("Por favor ingrese su Nombre de usuario");

        }

        private void LogOut(object sender, FormClosedEventArgs e)
        {
            txtUsuario.Clear();
            txtContraseña.Clear();
            lblErrorMessage.Visible = false;
            this.Show();
            txtUsuario.Focus();
        }



        private void Merror(string msg)
        {
            lblErrorMessage.Text = msg;
            lblErrorMessage.Visible = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_Click(object sender, EventArgs e)
        {
            farmacia_ped.recuperar frmrecuperar = new farmacia_ped.recuperar();

            frmrecuperar.Show();
            this.Hide();
        }
    }

}    

