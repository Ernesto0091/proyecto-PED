use master 



create database FARMACIA

use FARMACIA

-- Creacion  de tablas




create table users(
UserID int identity (1,1) primary key,
LoginName nvarchar (100) unique not null,
password nvarchar (100) not null,
FirstName nvarchar (100) not null,
LastName nvarchar (100) not null,
Position nvarchar (100) not null,
Email nvarchar (100) not null
)







  

create table Categoria
(
CodCategoria varchar(50) primary key ,
NombreCategoria varchar(100)not null
)

create table TipoProducto
(
TipoP varchar (50) primary key,
Descripcion varchar(300) not null
)


create table Producto
(
CodProducto varchar(50) primary key,
NombreProducto varchar (100) not null,
CategoriaProducto varchar (50) not null,
Tipoproduct varchar(50) not null,
Cantidad int not null,
DescripcionProducto varchar(500) not null,
FechaIngreso DateTime not null,
FechaVencimiento DateTime not null
)

alter table Producto
add Constraint CodCat_FK
foreign key (CategoriaProducto)
references Categoria (CodCategoria)


alter table Producto
add constraint TipoP_FK
foreign key (Tipoproduct)
references TipoProducto(TipoP)



--Restricciones


alter table producto
add constraint FV_P
Check (FechaVencimiento > getdate())

alter table producto
ADD constraint Cant_P
check (Cantidad>0)



insert into users values ('admin','admin','Ernesto','Mu�oz','adminisrador','samus.0091@gmail.com')
insert into users values ('Prueba','123','Santiago','Equisde','adminisrador','santiago@gmail.com')
insert into users values ('Elmer','Elmer1','Elmer','Samael','adminisrador','Elmer@gmail.com')
insert into users values ('Cesar','Cesar1','Cesar','Ramirez','adminisrador','Cesar@gmail.com')
insert into users values ('William','madremiawily','William','Amaya','adminisrador','William@gmail.com')
insert into users values ('Daniel','yamete','Daniel','Cruz','adminisrador','Daniel@gmail.com')

select * from users


select * from users where LoginName='admin' and password= 'admin'


declare @user nvarchar(100)='admin'
declare @pass nvarchar(100)='admin'
select * from users where LoginName= @user and password=@pass













